set serveroutput on;
begin
  dbms_output.put_line('Hello There');
end;

/

set serveroutput on;
declare
n_sales number:=20000;
BEGIN
if n_sales>50000 then
  dbms_output.put_line('sales revenue is greater than 100k');
else
  dbms_output.put_line('sales revenue is greater than 500k');
  end if;
end;


-- Basic Loop
set serveroutput on;
DECLARE
  l_counter NUMBER := 0;
BEGIN 
 LOOP
   l_counter := l_counter + 1;
   IF l_counter > 3 THEN
     EXIT;
   END IF;
   dbms_output.put_line('Inside loop: '|| l_counter);
 END LOOP;
 -- control resume here after EXIT
  dbms_output.put_line('After loop: '|| l_counter);
END;